import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Sparkles, AlertCircle, TrendingUp, Heart } from "lucide-react";

const suggestions = [
  {
    id: 1,
    type: "alert",
    icon: AlertCircle,
    title: "Increased Stress in Year 3 Electronics",
    description: "Post-exam stress levels up 18% from last month. Consider organizing a wellness workshop.",
    priority: "high"
  },
  {
    id: 2,
    type: "opportunity",
    icon: TrendingUp,
    title: "Engagement Rising in CS Department",
    description: "LMS activity increased by 24% after interactive lab sessions. Consider expanding this approach.",
    priority: "medium"
  },
  {
    id: 3,
    type: "wellness",
    icon: Heart,
    title: "Mental Health Week Impact",
    description: "Overall wellness scores improved by 12% during the wellness week. Plan quarterly events.",
    priority: "medium"
  }
];

export function AISuggestionsPanel() {
  const priorityColors = {
    high: "border-l-red-500 bg-red-50/50",
    medium: "border-l-yellow-500 bg-yellow-50/50",
    low: "border-l-green-500 bg-green-50/50"
  };

  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          AI-Powered Insights
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {suggestions.map((suggestion) => {
          const Icon = suggestion.icon;
          return (
            <div 
              key={suggestion.id}
              className={`p-4 rounded-lg border-l-4 ${priorityColors[suggestion.priority as keyof typeof priorityColors]} transition-smooth hover:shadow-soft`}
            >
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-lg gradient-primary flex items-center justify-center flex-shrink-0 shadow-soft">
                  <Icon className="w-5 h-5 text-primary-foreground" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm mb-1">{suggestion.title}</h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">{suggestion.description}</p>
                </div>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
