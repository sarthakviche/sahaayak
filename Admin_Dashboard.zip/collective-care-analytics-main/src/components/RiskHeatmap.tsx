import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const departments = [
  { name: "Computer Science", year1: 12, year2: 18, year3: 25, year4: 15 },
  { name: "Electronics", year1: 15, year2: 22, year3: 28, year4: 20 },
  { name: "Mechanical", year1: 20, year2: 25, year3: 32, year4: 28 },
  { name: "Civil", year1: 18, year2: 24, year3: 30, year4: 22 },
  { name: "Information Tech", year1: 10, year2: 16, year3: 20, year4: 12 },
];

function getRiskColor(value: number) {
  if (value < 15) return "bg-green-100 text-green-800 border-green-200";
  if (value < 25) return "bg-yellow-100 text-yellow-800 border-yellow-200";
  return "bg-red-100 text-red-800 border-red-200";
}

function getRiskLabel(value: number) {
  if (value < 15) return "Low";
  if (value < 25) return "Medium";
  return "High";
}

export function RiskHeatmap() {
  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Department Risk Overview
          <span className="text-xs font-normal text-muted-foreground">(% at risk)</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left py-3 px-4 text-sm font-semibold text-muted-foreground">Department</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-muted-foreground">Year 1</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-muted-foreground">Year 2</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-muted-foreground">Year 3</th>
                <th className="text-center py-3 px-4 text-sm font-semibold text-muted-foreground">Year 4</th>
              </tr>
            </thead>
            <tbody>
              {departments.map((dept) => (
                <tr key={dept.name} className="border-b border-border/50 hover:bg-muted/30 transition-smooth">
                  <td className="py-3 px-4 font-medium">{dept.name}</td>
                  <td className="py-3 px-4">
                    <div className={`mx-auto w-16 py-1 rounded-lg text-center text-sm font-semibold border ${getRiskColor(dept.year1)}`}>
                      {dept.year1}%
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className={`mx-auto w-16 py-1 rounded-lg text-center text-sm font-semibold border ${getRiskColor(dept.year2)}`}>
                      {dept.year2}%
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className={`mx-auto w-16 py-1 rounded-lg text-center text-sm font-semibold border ${getRiskColor(dept.year3)}`}>
                      {dept.year3}%
                    </div>
                  </td>
                  <td className="py-3 px-4">
                    <div className={`mx-auto w-16 py-1 rounded-lg text-center text-sm font-semibold border ${getRiskColor(dept.year4)}`}>
                      {dept.year4}%
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="flex justify-center gap-6 mt-6 pt-4 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-green-100 border border-green-200" />
            <span className="text-sm text-muted-foreground">Low Risk (&lt;15%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-yellow-100 border border-yellow-200" />
            <span className="text-sm text-muted-foreground">Medium Risk (15-25%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded bg-red-100 border border-red-200" />
            <span className="text-sm text-muted-foreground">High Risk (&gt;25%)</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
