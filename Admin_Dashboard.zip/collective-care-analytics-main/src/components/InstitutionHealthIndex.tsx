import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp } from "lucide-react";

const healthScore = 76;

export function InstitutionHealthIndex() {
  const getScoreColor = (score: number) => {
    if (score >= 75) return "text-green-600";
    if (score >= 50) return "text-yellow-600";
    return "text-red-600";
  };

  const getScoreGradient = (score: number) => {
    if (score >= 75) return "from-green-500 to-emerald-500";
    if (score >= 50) return "from-yellow-500 to-orange-500";
    return "from-red-500 to-rose-500";
  };

  return (
    <Card className="gradient-card shadow-medium border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>Institution Health Index (IHI)</span>
          <TrendingUp className="w-5 h-5 text-green-600" />
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center space-y-6">
          {/* Circular Progress */}
          <div className="relative w-48 h-48">
            <svg className="w-full h-full transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="hsl(270, 20%, 90%)"
                strokeWidth="12"
                fill="none"
              />
              <circle
                cx="96"
                cy="96"
                r="88"
                stroke="url(#healthGradient)"
                strokeWidth="12"
                fill="none"
                strokeDasharray={`${2 * Math.PI * 88}`}
                strokeDashoffset={`${2 * Math.PI * 88 * (1 - healthScore / 100)}`}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
              <defs>
                <linearGradient id="healthGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="hsl(252, 85%, 75%)" />
                  <stop offset="100%" stopColor="hsl(270, 60%, 65%)" />
                </linearGradient>
              </defs>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className={`text-5xl font-bold ${getScoreColor(healthScore)}`}>
                {healthScore}
              </span>
              <span className="text-sm text-muted-foreground mt-1">out of 100</span>
            </div>
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-6 w-full">
            <div className="text-center">
              <p className="text-2xl font-bold text-primary">82%</p>
              <p className="text-xs text-muted-foreground mt-1">Wellness</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-secondary">74%</p>
              <p className="text-xs text-muted-foreground mt-1">Engagement</p>
            </div>
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">72%</p>
              <p className="text-xs text-muted-foreground mt-1">Retention</p>
            </div>
          </div>

          <p className="text-sm text-center text-muted-foreground leading-relaxed">
            Overall institutional health is <span className="font-semibold text-foreground">good</span>. 
            Wellness scores improved by 8% this quarter while maintaining strong engagement levels.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
