import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const metrics = ["Attendance", "LMS Activity", "Stress Level", "Backlogs", "Engagement"];

const correlationData = [
  [1.00, 0.82, -0.65, -0.58, 0.76],
  [0.82, 1.00, -0.71, -0.62, 0.84],
  [-0.65, -0.71, 1.00, 0.68, -0.78],
  [-0.58, -0.62, 0.68, 1.00, -0.54],
  [0.76, 0.84, -0.78, -0.54, 1.00]
];

function getCorrelationColor(value: number) {
  const abs = Math.abs(value);
  if (abs < 0.3) return "bg-gray-100 text-gray-700";
  if (abs < 0.6) return value > 0 ? "bg-green-200 text-green-900" : "bg-orange-200 text-orange-900";
  return value > 0 ? "bg-green-400 text-green-950" : "bg-red-400 text-red-950";
}

export function CorrelationMatrix() {
  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle>Metric Correlation Analysis</CardTitle>
        <p className="text-sm text-muted-foreground">
          Understanding relationships between academic and emotional factors
        </p>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <div className="inline-block min-w-full">
            <div className="grid grid-cols-6 gap-1">
              <div></div>
              {metrics.map((metric, idx) => (
                <div key={idx} className="text-xs font-semibold text-center p-2">
                  {metric}
                </div>
              ))}
              
              {metrics.map((rowMetric, rowIdx) => (
                <>
                  <div key={`label-${rowIdx}`} className="text-xs font-semibold p-2 flex items-center">
                    {rowMetric}
                  </div>
                  {correlationData[rowIdx].map((value, colIdx) => (
                    <div
                      key={`cell-${rowIdx}-${colIdx}`}
                      className={`p-3 text-center text-sm font-semibold rounded ${getCorrelationColor(value)}`}
                    >
                      {value.toFixed(2)}
                    </div>
                  ))}
                </>
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-6 p-4 bg-muted/30 rounded-lg">
          <p className="text-sm font-semibold mb-2">Key Insights:</p>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>• Strong positive correlation (0.84) between LMS activity and engagement</li>
            <li>• High negative correlation (-0.78) between stress levels and engagement</li>
            <li>• Attendance and LMS activity show strong positive relationship (0.82)</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
