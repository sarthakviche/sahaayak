import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from "recharts";

const data = [
  { month: "Jan", happy: 45, neutral: 35, stressed: 15, anxious: 5 },
  { month: "Feb", happy: 48, neutral: 32, stressed: 14, anxious: 6 },
  { month: "Mar", happy: 38, neutral: 30, stressed: 22, anxious: 10 },
  { month: "Apr", happy: 52, neutral: 28, stressed: 15, anxious: 5 },
  { month: "May", happy: 55, neutral: 27, stressed: 12, anxious: 6 },
  { month: "Jun", happy: 50, neutral: 30, stressed: 14, anxious: 6 },
];

export function EmotionalTrendChart() {
  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle>Emotional State Distribution</CardTitle>
        <p className="text-sm text-muted-foreground">Aggregated emotional trends across all students</p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={350}>
          <BarChart data={data}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(270, 20%, 90%)" />
            <XAxis 
              dataKey="month" 
              stroke="hsl(270, 25%, 45%)"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="hsl(270, 25%, 45%)"
              style={{ fontSize: '12px' }}
              label={{ value: '% of Students', angle: -90, position: 'insideLeft' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(0, 0%, 100%)',
                border: '1px solid hsl(270, 20%, 90%)',
                borderRadius: '8px',
                boxShadow: '0 4px 16px -4px hsl(252, 85%, 75% / 0.15)'
              }}
            />
            <Legend />
            <Bar dataKey="happy" fill="hsl(142, 71%, 45%)" name="Happy/Content" radius={[4, 4, 0, 0]} />
            <Bar dataKey="neutral" fill="hsl(252, 85%, 75%)" name="Neutral" radius={[4, 4, 0, 0]} />
            <Bar dataKey="stressed" fill="hsl(38, 92%, 50%)" name="Stressed" radius={[4, 4, 0, 0]} />
            <Bar dataKey="anxious" fill="hsl(0, 72%, 51%)" name="Anxious" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
