import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts";

const data = [
  { month: "Jan", wellness: 72, engagement: 68, stress: 42 },
  { month: "Feb", wellness: 75, engagement: 71, stress: 38 },
  { month: "Mar", wellness: 68, engagement: 65, stress: 52 },
  { month: "Apr", wellness: 78, engagement: 76, stress: 35 },
  { month: "May", wellness: 82, engagement: 80, stress: 28 },
  { month: "Jun", wellness: 79, engagement: 77, stress: 32 },
];

export function WellnessTrendChart() {
  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          Wellness Trends Overview
          <span className="text-xs font-normal text-muted-foreground">(Last 6 Months)</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={300}>
          <AreaChart data={data}>
            <defs>
              <linearGradient id="wellnessGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(252, 85%, 75%)" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(252, 85%, 75%)" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="engagementGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="hsl(270, 60%, 65%)" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="hsl(270, 60%, 65%)" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(270, 20%, 90%)" />
            <XAxis 
              dataKey="month" 
              stroke="hsl(270, 25%, 45%)"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="hsl(270, 25%, 45%)"
              style={{ fontSize: '12px' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: 'hsl(0, 0%, 100%)',
                border: '1px solid hsl(270, 20%, 90%)',
                borderRadius: '8px',
                boxShadow: '0 4px 16px -4px hsl(252, 85%, 75% / 0.15)'
              }}
            />
            <Area 
              type="monotone" 
              dataKey="wellness" 
              stroke="hsl(252, 85%, 75%)" 
              strokeWidth={3}
              fill="url(#wellnessGradient)"
            />
            <Area 
              type="monotone" 
              dataKey="engagement" 
              stroke="hsl(270, 60%, 65%)" 
              strokeWidth={3}
              fill="url(#engagementGradient)"
            />
          </AreaChart>
        </ResponsiveContainer>
        <div className="flex justify-center gap-6 mt-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-primary" />
            <span className="text-sm text-muted-foreground">Wellness Score</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-secondary" />
            <span className="text-sm text-muted-foreground">Engagement Level</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
