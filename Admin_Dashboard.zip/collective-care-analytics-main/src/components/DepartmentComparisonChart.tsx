import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from "recharts";

const data = [
  { metric: "Wellness", CS: 82, ECE: 75, ME: 68, CE: 72, IT: 85 },
  { metric: "Engagement", CS: 88, ECE: 78, ME: 70, CE: 74, IT: 90 },
  { metric: "Attendance", CS: 85, ECE: 80, ME: 72, CE: 76, IT: 87 },
  { metric: "Performance", CS: 86, ECE: 82, ME: 75, CE: 78, IT: 88 },
  { metric: "Support Access", CS: 65, ECE: 70, ME: 62, CE: 68, IT: 72 }
];

export function DepartmentComparisonChart() {
  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle>Department Performance Radar</CardTitle>
        <p className="text-sm text-muted-foreground">Multi-metric comparison across departments</p>
      </CardHeader>
      <CardContent>
        <ResponsiveContainer width="100%" height={400}>
          <RadarChart data={data}>
            <PolarGrid stroke="hsl(270, 20%, 90%)" />
            <PolarAngleAxis 
              dataKey="metric" 
              tick={{ fill: 'hsl(270, 25%, 45%)', fontSize: 12 }}
            />
            <PolarRadiusAxis 
              angle={90} 
              domain={[0, 100]}
              tick={{ fill: 'hsl(270, 25%, 45%)', fontSize: 10 }}
            />
            <Radar 
              name="Computer Science" 
              dataKey="CS" 
              stroke="hsl(252, 85%, 75%)" 
              fill="hsl(252, 85%, 75%)" 
              fillOpacity={0.3}
              strokeWidth={2}
            />
            <Radar 
              name="Electronics" 
              dataKey="ECE" 
              stroke="hsl(270, 60%, 65%)" 
              fill="hsl(270, 60%, 65%)" 
              fillOpacity={0.3}
              strokeWidth={2}
            />
            <Radar 
              name="Information Tech" 
              dataKey="IT" 
              stroke="hsl(280, 75%, 80%)" 
              fill="hsl(280, 75%, 80%)" 
              fillOpacity={0.3}
              strokeWidth={2}
            />
            <Legend />
          </RadarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
