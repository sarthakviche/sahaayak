import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, AlertTriangle, Sparkles, CheckCircle } from "lucide-react";

const forecasts = [
  {
    id: 1,
    type: "positive",
    icon: TrendingUp,
    title: "Wellness Improvement Expected",
    prediction: "Based on current trends, overall wellness scores are projected to increase by 6-8% over the next month.",
    confidence: 87,
    reasoning: "Recent stress reduction initiatives and exam completion are showing positive impact."
  },
  {
    id: 2,
    type: "warning",
    icon: AlertTriangle,
    title: "Engagement Dip Forecasted",
    prediction: "Year 3 Mechanical Engineering may experience a 10% engagement decrease post-finals.",
    confidence: 72,
    reasoning: "Historical patterns show reduced activity during semester breaks."
  },
  {
    id: 3,
    type: "insight",
    icon: Sparkles,
    title: "Optimal Intervention Window",
    prediction: "Next 2 weeks are ideal for implementing support programs with 92% effectiveness rate.",
    confidence: 94,
    reasoning: "Students are more receptive to wellness initiatives during mid-semester periods."
  }
];

export function AIForecastPanel() {
  const typeStyles = {
    positive: "border-green-500 bg-green-50/50",
    warning: "border-yellow-500 bg-yellow-50/50",
    insight: "border-primary bg-primary/5"
  };

  const iconColors = {
    positive: "text-green-600",
    warning: "text-yellow-600",
    insight: "text-primary"
  };

  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-primary" />
          AI Wellness Forecast
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Predictive insights for the next 30 days
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        {forecasts.map((forecast) => {
          const Icon = forecast.icon;
          return (
            <div 
              key={forecast.id}
              className={`p-4 rounded-lg border-l-4 ${typeStyles[forecast.type as keyof typeof typeStyles]} transition-smooth hover:shadow-soft`}
            >
              <div className="flex items-start gap-3 mb-3">
                <div className={`${iconColors[forecast.type as keyof typeof iconColors]}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold text-sm mb-1">{forecast.title}</h4>
                  <p className="text-sm text-foreground leading-relaxed mb-2">
                    {forecast.prediction}
                  </p>
                </div>
              </div>
              
              <div className="pl-8 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground">Confidence</span>
                  <span className="font-semibold">{forecast.confidence}%</span>
                </div>
                <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full gradient-primary transition-all duration-1000"
                    style={{ width: `${forecast.confidence}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground italic mt-2">
                  {forecast.reasoning}
                </p>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
