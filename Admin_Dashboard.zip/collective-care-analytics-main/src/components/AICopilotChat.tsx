import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Bot, Send } from "lucide-react";
import { useState } from "react";

const sampleQueries = [
  "What departments need the most support right now?",
  "How can we improve Year 3 engagement?",
  "Suggest wellness interventions for next month"
];

export function AICopilotChat() {
  const [query, setQuery] = useState("");

  return (
    <Card className="gradient-card shadow-soft border-border/50">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bot className="w-5 h-5 text-primary" />
          AI Institutional Copilot
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Ask questions about your institution's wellness data
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm font-semibold">Try asking:</p>
          {sampleQueries.map((sample, idx) => (
            <button
              key={idx}
              onClick={() => setQuery(sample)}
              className="block w-full text-left p-3 rounded-lg bg-muted/30 hover:bg-muted/50 text-sm transition-smooth"
            >
              "{sample}"
            </button>
          ))}
        </div>
        
        <div className="pt-4 border-t border-border">
          <div className="flex gap-2">
            <Input
              placeholder="Ask the AI copilot..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="flex-1"
            />
            <Button className="gradient-primary shadow-soft">
              <Send className="w-4 h-4" />
            </Button>
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            AI responses are based on aggregated, anonymized data
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
