import { Card, CardContent } from "@/components/ui/card";
import { LucideIcon } from "lucide-react";

interface DepartmentMetricCardProps {
  department: string;
  students: number;
  wellnessScore: number;
  atRisk: number;
  engagement: number;
  icon: LucideIcon;
}

export function DepartmentMetricCard({ 
  department, 
  students, 
  wellnessScore, 
  atRisk, 
  engagement,
  icon: Icon 
}: DepartmentMetricCardProps) {
  return (
    <Card className="gradient-card shadow-soft border-border/50 transition-smooth hover:shadow-medium">
      <CardContent className="p-6">
        <div className="flex items-start justify-between mb-4">
          <div>
            <h3 className="text-xl font-bold">{department}</h3>
            <p className="text-sm text-muted-foreground">{students} students</p>
          </div>
          <div className="w-12 h-12 rounded-xl gradient-primary flex items-center justify-center shadow-soft">
            <Icon className="w-6 h-6 text-primary-foreground" />
          </div>
        </div>
        
        <div className="grid grid-cols-3 gap-4">
          <div>
            <p className="text-2xl font-bold text-primary">{wellnessScore}%</p>
            <p className="text-xs text-muted-foreground mt-1">Wellness</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-destructive">{atRisk}</p>
            <p className="text-xs text-muted-foreground mt-1">At Risk</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-green-600">{engagement}%</p>
            <p className="text-xs text-muted-foreground mt-1">Engaged</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
