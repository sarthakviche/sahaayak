import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingDown, TrendingUp, AlertCircle } from "lucide-react";

interface PredictionCardProps {
  department: string;
  year: string;
  riskLevel: "low" | "medium" | "high";
  percentage: number;
  trend: "up" | "down";
  factors: string[];
}

export function PredictionCard({ department, year, riskLevel, percentage, trend, factors }: PredictionCardProps) {
  const riskColors = {
    low: "border-green-500 bg-green-50/50",
    medium: "border-yellow-500 bg-yellow-50/50",
    high: "border-red-500 bg-red-50/50"
  };

  const riskBadgeColors = {
    low: "bg-green-100 text-green-800 border-green-200",
    medium: "bg-yellow-100 text-yellow-800 border-yellow-200",
    high: "bg-red-100 text-red-800 border-red-200"
  };

  return (
    <Card className={`border-l-4 ${riskColors[riskLevel]} shadow-soft transition-smooth hover:shadow-medium`}>
      <CardHeader>
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg">{department}</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">{year}</p>
          </div>
          <div className={`px-3 py-1 rounded-full text-xs font-semibold border ${riskBadgeColors[riskLevel]}`}>
            {riskLevel.toUpperCase()} RISK
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-3xl font-bold">{percentage}%</p>
            <p className="text-sm text-muted-foreground">Predicted dropout risk</p>
          </div>
          <div className={`flex items-center gap-1 ${trend === 'down' ? 'text-green-600' : 'text-red-600'}`}>
            {trend === 'down' ? <TrendingDown className="w-5 h-5" /> : <TrendingUp className="w-5 h-5" />}
            <span className="text-sm font-semibold">{trend === 'down' ? 'Improving' : 'Declining'}</span>
          </div>
        </div>
        
        <div className="pt-4 border-t border-border">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-muted-foreground mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold mb-2">Key Risk Factors:</p>
              <ul className="space-y-1">
                {factors.map((factor, idx) => (
                  <li key={idx} className="text-sm text-muted-foreground">• {factor}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
