import { DashboardLayout } from "@/components/DashboardLayout";
import { DepartmentMetricCard } from "@/components/DepartmentMetricCard";
import { DepartmentComparisonChart } from "@/components/DepartmentComparisonChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Cpu, Zap, Cog, Building, Code } from "lucide-react";

const departments = [
  {
    department: "Computer Science",
    students: 842,
    wellnessScore: 82,
    atRisk: 68,
    engagement: 88,
    icon: Code
  },
  {
    department: "Electronics & Telecom",
    students: 687,
    wellnessScore: 75,
    atRisk: 95,
    engagement: 78,
    icon: Zap
  },
  {
    department: "Mechanical Engineering",
    students: 756,
    wellnessScore: 68,
    atRisk: 142,
    engagement: 70,
    icon: Cog
  },
  {
    department: "Civil Engineering",
    students: 624,
    wellnessScore: 72,
    atRisk: 82,
    engagement: 74,
    icon: Building
  },
  {
    department: "Information Technology",
    students: 938,
    wellnessScore: 85,
    atRisk: 52,
    engagement: 90,
    icon: Cpu
  }
];

const departmentInsights = [
  {
    dept: "Information Technology",
    insight: "Highest wellness and engagement scores. Active participation in support programs.",
    status: "excellent"
  },
  {
    dept: "Mechanical Engineering",
    insight: "Requires attention: High at-risk count and lower engagement. Consider targeted interventions.",
    status: "concern"
  },
  {
    dept: "Computer Science",
    insight: "Strong performance with balanced metrics. Maintain current support structure.",
    status: "good"
  },
  {
    dept: "Electronics & Telecom",
    insight: "Moderate risk levels. Stress appears elevated - recommend wellness workshops.",
    status: "moderate"
  }
];

const Departments = () => {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold mb-2">Department Analytics</h1>
          <p className="text-muted-foreground">
            Comparative analysis across departments for targeted interventions
          </p>
        </div>

        {/* Department Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {departments.map((dept, idx) => (
            <DepartmentMetricCard key={idx} {...dept} />
          ))}
        </div>

        {/* Comparison Chart */}
        <DepartmentComparisonChart />

        {/* Department Insights */}
        <Card className="gradient-card shadow-soft border-border/50">
          <CardHeader>
            <CardTitle>AI-Generated Department Insights</CardTitle>
            <p className="text-sm text-muted-foreground">
              Actionable recommendations based on department-level analytics
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {departmentInsights.map((item, idx) => (
                <div 
                  key={idx}
                  className={`p-4 rounded-lg border-l-4 transition-smooth ${
                    item.status === 'excellent'
                      ? 'border-green-500 bg-green-50/50'
                      : item.status === 'concern'
                      ? 'border-red-500 bg-red-50/50'
                      : item.status === 'good'
                      ? 'border-primary bg-primary/5'
                      : 'border-yellow-500 bg-yellow-50/50'
                  }`}
                >
                  <h4 className="font-semibold text-sm mb-2">{item.dept}</h4>
                  <p className="text-sm text-muted-foreground">{item.insight}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Summary Banner */}
        <div className="p-6 rounded-xl gradient-primary text-primary-foreground shadow-glow">
          <h3 className="text-lg font-bold mb-2">Department Overview Summary</h3>
          <p className="text-sm leading-relaxed opacity-95">
            <strong>Information Technology and Computer Science</strong> departments show strong overall health metrics. 
            <strong> Mechanical Engineering</strong> requires focused support with 142 at-risk students. 
            Consider department-specific wellness initiatives and enhanced academic support structures.
          </p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Departments;
