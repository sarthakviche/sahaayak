import { DashboardLayout } from "@/components/DashboardLayout";
import { AIForecastPanel } from "@/components/AIForecastPanel";
import { AICopilotChat } from "@/components/AICopilotChat";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MetricCard } from "@/components/MetricCard";
import { Brain, Sparkles, Target, Lightbulb } from "lucide-react";

const recommendations = [
  {
    title: "Organize Post-Exam Mindfulness Workshop",
    priority: "high",
    impact: "High Impact",
    reason: "Students showing 18% higher stress post-exams. Interactive stress-relief sessions could improve wellness by 12-15%.",
    departments: ["Mechanical Eng", "Civil Eng"]
  },
  {
    title: "Extend Library Hours During Project Season",
    priority: "medium",
    impact: "Medium Impact",
    reason: "LMS data shows peak activity between 8-11 PM. Extended study spaces could boost engagement by 8%.",
    departments: ["All Departments"]
  },
  {
    title: "Launch Peer Mentorship Program",
    priority: "high",
    impact: "High Impact",
    reason: "Year 1 students with mentors show 23% better retention. Expand program to at-risk cohorts.",
    departments: ["Year 1 & 2 - All"]
  },
  {
    title: "Stagger Assignment Deadlines",
    priority: "medium",
    impact: "Medium Impact",
    reason: "Clustering of deadlines correlates with 15% stress spike. Spread submissions across 2-week windows.",
    departments: ["Course Coordinators"]
  }
];

const AIInsights = () => {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold mb-2">AI Insights & Predictions</h1>
          <p className="text-muted-foreground">
            Advanced AI-powered forecasts, recommendations, and conversational analytics
          </p>
        </div>

        {/* AI Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <MetricCard
            title="Prediction Accuracy"
            value="89%"
            change="Historical validation"
            changeType="positive"
            icon={Target}
          />
          <MetricCard
            title="Active Models"
            value="5"
            change="Wellness, Risk, Engagement"
            changeType="neutral"
            icon={Brain}
          />
          <MetricCard
            title="Insights Generated"
            value="247"
            change="This semester"
            changeType="positive"
            icon={Sparkles}
          />
          <MetricCard
            title="Intervention Success"
            value="76%"
            change="Based on AI recommendations"
            changeType="positive"
            icon={Lightbulb}
          />
        </div>

        {/* Main Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Forecasts and Recommendations */}
          <div className="lg:col-span-2 space-y-6">
            <AIForecastPanel />
            
            {/* Recommendations */}
            <Card className="gradient-card shadow-soft border-border/50">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="w-5 h-5 text-primary" />
                  AI-Generated Recommendations
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Contextual suggestions for institutional wellness programs
                </p>
              </CardHeader>
              <CardContent className="space-y-4">
                {recommendations.map((rec, idx) => (
                  <div 
                    key={idx}
                    className={`p-4 rounded-lg border-l-4 transition-smooth hover:shadow-soft ${
                      rec.priority === 'high'
                        ? 'border-red-500 bg-red-50/50'
                        : 'border-yellow-500 bg-yellow-50/50'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-sm">{rec.title}</h4>
                      <span className={`text-xs px-2 py-1 rounded-full font-semibold ${
                        rec.priority === 'high'
                          ? 'bg-red-100 text-red-800'
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {rec.impact}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">{rec.reason}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-muted-foreground">Target:</span>
                      {rec.departments.map((dept, i) => (
                        <span key={i} className="text-xs px-2 py-1 bg-primary/10 text-primary rounded">
                          {dept}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Right Column - AI Copilot */}
          <div>
            <AICopilotChat />
          </div>
        </div>

        {/* AI Model Info */}
        <Card className="gradient-card shadow-soft border-border/50">
          <CardHeader>
            <CardTitle>AI Model Information</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-semibold mb-2">Dropout Prediction Model</h4>
                <p className="text-sm text-muted-foreground">
                  Uses attendance, academic performance, LMS activity, and emotional wellness data. 
                  Trained on 3 years of historical data with 89% accuracy.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Wellness Forecasting</h4>
                <p className="text-sm text-muted-foreground">
                  Time-series analysis of emotional health trends combined with academic calendars. 
                  Predicts wellness trajectories 30-60 days ahead.
                </p>
              </div>
              <div>
                <h4 className="font-semibold mb-2">Intervention Optimizer</h4>
                <p className="text-sm text-muted-foreground">
                  Recommends timing and type of wellness programs based on effectiveness data. 
                  Learns from past intervention outcomes.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
};

export default AIInsights;
