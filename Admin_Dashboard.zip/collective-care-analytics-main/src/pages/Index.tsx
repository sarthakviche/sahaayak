import { DashboardLayout } from "@/components/DashboardLayout";
import { MetricCard } from "@/components/MetricCard";
import { WellnessTrendChart } from "@/components/WellnessTrendChart";
import { RiskHeatmap } from "@/components/RiskHeatmap";
import { AISuggestionsPanel } from "@/components/AISuggestionsPanel";
import { InstitutionHealthIndex } from "@/components/InstitutionHealthIndex";
import { Users, TrendingUp, Heart, AlertTriangle } from "lucide-react";

const Index = () => {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold mb-2">Dashboard Overview</h1>
          <p className="text-muted-foreground">
            Privacy-first analytics for institutional wellness and student success
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard
            title="Total Students"
            value="3,847"
            change="+5.2% from last semester"
            changeType="positive"
            icon={Users}
          />
          <MetricCard
            title="Average Wellness Score"
            value="78%"
            change="+8% this month"
            changeType="positive"
            icon={Heart}
          />
          <MetricCard
            title="At-Risk Students"
            value="387"
            change="-12% reduction"
            changeType="positive"
            icon={AlertTriangle}
          />
          <MetricCard
            title="Engagement Rate"
            value="82%"
            change="+3.5% increase"
            changeType="positive"
            icon={TrendingUp}
          />
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <InstitutionHealthIndex />
            <WellnessTrendChart />
            <RiskHeatmap />
          </div>
          <div>
            <AISuggestionsPanel />
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default Index;
