import { DashboardLayout } from "@/components/DashboardLayout";
import { MetricCard } from "@/components/MetricCard";
import { EmotionalTrendChart } from "@/components/EmotionalTrendChart";
import { WellnessTrendChart } from "@/components/WellnessTrendChart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, TrendingUp, Smile, Brain } from "lucide-react";

const wellnessInsights = [
  {
    period: "Post Mid-Semester",
    change: "+12%",
    description: "Stress levels dropped by 12% after mid-semester exams completed",
    type: "positive"
  },
  {
    period: "Assignment Peak Week",
    change: "-8%",
    description: "Overall wellness dipped during multiple assignment deadlines",
    type: "negative"
  },
  {
    period: "Mental Health Week",
    change: "+15%",
    description: "Wellness scores improved significantly during campus-wide wellness initiative",
    type: "positive"
  },
  {
    period: "Project Submissions",
    change: "-5%",
    description: "Minor stress increase during final project submission period",
    type: "neutral"
  }
];

const WellnessTrends = () => {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold mb-2">Wellness Trends & Emotional Analytics</h1>
          <p className="text-muted-foreground">
            Anonymous aggregated insights on student emotional health and well-being patterns
          </p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <MetricCard
            title="Average Wellness"
            value="78%"
            change="+8% this month"
            changeType="positive"
            icon={Heart}
          />
          <MetricCard
            title="Stress Index"
            value="32%"
            change="-14% decrease"
            changeType="positive"
            icon={Brain}
          />
          <MetricCard
            title="Positive Emotions"
            value="65%"
            change="+5% increase"
            changeType="positive"
            icon={Smile}
          />
          <MetricCard
            title="Support Access"
            value="42%"
            change="+18% uptick"
            changeType="positive"
            icon={TrendingUp}
          />
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <WellnessTrendChart />
          <EmotionalTrendChart />
        </div>

        {/* Key Events Impact */}
        <Card className="gradient-card shadow-soft border-border/50">
          <CardHeader>
            <CardTitle>Wellness Events Impact Timeline</CardTitle>
            <p className="text-sm text-muted-foreground">
              How academic events and initiatives affected student wellness
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {wellnessInsights.map((insight, idx) => (
                <div 
                  key={idx}
                  className={`p-4 rounded-lg border-l-4 transition-smooth ${
                    insight.type === 'positive' 
                      ? 'border-green-500 bg-green-50/50' 
                      : insight.type === 'negative'
                      ? 'border-red-500 bg-red-50/50'
                      : 'border-yellow-500 bg-yellow-50/50'
                  }`}
                >
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="font-semibold text-sm">{insight.period}</h4>
                    <span className={`text-lg font-bold ${
                      insight.type === 'positive' 
                        ? 'text-green-600' 
                        : insight.type === 'negative'
                        ? 'text-red-600'
                        : 'text-yellow-600'
                    }`}>
                      {insight.change}
                    </span>
                  </div>
                  <p className="text-sm text-muted-foreground">{insight.description}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Summary Insight */}
        <div className="p-6 rounded-xl gradient-primary text-primary-foreground shadow-glow">
          <h3 className="text-lg font-bold mb-2">AI Summary</h3>
          <p className="text-sm leading-relaxed opacity-95">
            Overall emotional health trends are <strong>positive</strong>. If current stress trajectory continues, 
            expect a 10% improvement in engagement levels post-finals. Recommend maintaining regular wellness 
            check-ins and organizing lighter activities during high-stress academic periods.
          </p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default WellnessTrends;
