import { DashboardLayout } from "@/components/DashboardLayout";
import { PredictionCard } from "@/components/PredictionCard";
import { MetricCard } from "@/components/MetricCard";
import { CorrelationMatrix } from "@/components/CorrelationMatrix";
import { AlertTriangle, Users, TrendingDown, Target } from "lucide-react";

const predictions = [
  {
    department: "Mechanical Engineering",
    year: "Year 3",
    riskLevel: "high" as const,
    percentage: 32,
    trend: "up" as const,
    factors: [
      "Attendance below 75% average",
      "LMS activity decreased 28%",
      "High backlog concentration (45% have 2+ backlogs)"
    ]
  },
  {
    department: "Electronics & Telecom",
    year: "Year 2",
    riskLevel: "medium" as const,
    percentage: 22,
    trend: "down" as const,
    factors: [
      "Fee payment delays detected",
      "Stress levels above institutional average",
      "Mid-semester exam performance dip"
    ]
  },
  {
    department: "Computer Science",
    year: "Year 4",
    riskLevel: "low" as const,
    percentage: 15,
    trend: "down" as const,
    factors: [
      "Placement stress (normal seasonal)",
      "Project submission deadlines clustering",
      "Overall metrics within healthy range"
    ]
  },
  {
    department: "Civil Engineering",
    year: "Year 3",
    riskLevel: "medium" as const,
    percentage: 24,
    trend: "up" as const,
    factors: [
      "Reduced lab participation",
      "Increased stress reports post mid-terms",
      "Engagement score trending downward"
    ]
  }
];

const RiskAnalysis = () => {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold mb-2">Risk Analysis & Dropout Prediction</h1>
          <p className="text-muted-foreground">
            AI-powered predictions based on attendance, engagement, academic performance, and emotional wellness
          </p>
        </div>

        {/* Summary Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <MetricCard
            title="High Risk Groups"
            value="4"
            change="Same as last month"
            changeType="neutral"
            icon={AlertTriangle}
          />
          <MetricCard
            title="Students Flagged"
            value="387"
            change="-12% from last month"
            changeType="positive"
            icon={Users}
          />
          <MetricCard
            title="Risk Reduction"
            value="18%"
            change="Year-over-year improvement"
            changeType="positive"
            icon={TrendingDown}
          />
          <MetricCard
            title="Prediction Accuracy"
            value="89%"
            change="Based on historical data"
            changeType="positive"
            icon={Target}
          />
        </div>

        {/* AI Insights Banner */}
        <div className="p-6 rounded-xl gradient-primary text-primary-foreground shadow-glow">
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 rounded-lg bg-white/20 flex items-center justify-center flex-shrink-0">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-bold mb-2">AI Recommendation</h3>
              <p className="text-sm leading-relaxed opacity-95">
                3rd-year Mechanical Engineering shows a 22% high-risk cluster. Reduced LMS activity and low attendance detected 
                after mid-semesters. <strong>Suggest engagement check-ins and academic support workshops.</strong>
              </p>
            </div>
          </div>
        </div>

        {/* Prediction Cards */}
        <div>
          <h2 className="text-xl font-bold mb-4">Department-Year Risk Predictions</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {predictions.map((pred, idx) => (
              <PredictionCard key={idx} {...pred} />
            ))}
          </div>
        </div>

        {/* Correlation Analysis */}
        <CorrelationMatrix />
      </div>
    </DashboardLayout>
  );
};

export default RiskAnalysis;
