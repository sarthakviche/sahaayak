import { DashboardLayout } from "@/components/DashboardLayout";

const PrivacySettings = () => {
  return (
    <DashboardLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Privacy Settings</h1>
          <p className="text-muted-foreground">
            Configure data anonymization and consent management
          </p>
        </div>
        <div className="text-center py-16">
          <p className="text-muted-foreground">Coming soon: Privacy configuration panel</p>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default PrivacySettings;
